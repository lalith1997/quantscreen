"""QuantScreen Backend Application."""
